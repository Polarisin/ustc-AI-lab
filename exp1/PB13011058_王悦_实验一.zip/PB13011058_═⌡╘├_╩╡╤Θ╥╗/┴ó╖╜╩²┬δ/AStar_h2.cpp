//A* h2
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <cstring>
#include <ctime>
#include <hash_set>
#include <queue>
using namespace std;
using namespace __gnu_cxx;
namespace __gnu_cxx {  
    template<>  
    struct hash<std::string>  
    {  
        hash<char*> h;  
        size_t operator()(const std::string &s) const  
        {  
            return h(s.c_str());  
        };  
    };  
}
typedef struct Node{
	char state[28];
	unsigned int f, g;
	char *path;
	unsigned char sp;
	bool lessthan (const Node* node) const {
		return g < node->g;
	}
}Node;
class CompareNode{
public:
	bool operator () (Node* node1,Node* node2){
		return node1->lessthan(node2);
	}
};
static size_t sizeofNode = sizeof(Node);
static char state0[27];
static char stateN[27];
static unsigned char oper[27] = {	//U,D,L,R,F,B
	0x15, 0x1d, 0x19,
	0x35, 0x3d, 0x39,
	0x25, 0x2d, 0x29,

	0x17, 0x1f, 0x1b,
	0x37, 0x3f, 0x3b,
	0x27, 0x2f, 0x2b,

	0x16, 0x1e, 0x1a,
	0x36, 0x3e, 0x3a,
	0x26, 0x2e, 0x2a
};
static int dircsp[] = { 9, -9, 1, -1, 3, -3 };
static char dircpt[] = { 'B', 'F', 'R', 'L', 'D', 'U' };
static char valueH2[27][27];
static priority_queue<Node*, vector<Node*>, CompareNode> leaf[2];
static priority_queue<Node*, vector<Node*>, CompareNode> tempList;
static hash_set<string> innode;
static hash_set<string>::iterator endit;
static Node *goal, *last;
char* ASH2(){
	int i;
	//initial root
	Node *root = (Node*)malloc(sizeofNode);
	memcpy(root->state, state0, 27);
	int h = 0;
	int len = 0;
	unsigned char opbyte, lastop = 0;
	root->state[27] = 0;
	root->g = 0;
	int t;
	for (i = 0; i < 27; i++){
		t = state0[i] ^ 0x20;
		if (t > 0){
			h += valueH2[t][i];
		}
		else if (t == 0){
			root->sp = i;
		}
	}
	root->f = h;
	root->path = (char *)calloc(1, 1);
	//astar
	goal = root;
	endit = innode.end();
	while (goal->f != len){
		if (len > 0){
			switch (goal->path[len - 1]){
			case 'U':lastop = 0x10; break;
			case 'D':lastop = 0x20; break;
			case 'L':lastop = 0x04; break;
			case 'R':lastop = 0x08; break;
			case 'F':lastop = 0x01; break;
			case 'B':lastop = 0x02; break;
			}
		}
		opbyte = oper[goal->sp] ^ lastop;
		for (i = 5; i >= 0; i--){
			if ((opbyte >> i) & 0x01){
				last = (Node*)malloc(sizeofNode);
				memcpy(last->state, goal->state, 28);
				last->path = (char *)malloc(len + 2);
				memcpy(last->path, goal->path, len);
				last->sp = goal->sp + dircsp[i];
				last->state[goal->sp] = last->state[last->sp];
				last->state[last->sp] = 0x20;
				last->path[len] = dircpt[i];
				last->path[len + 1] = 0;
				last->g = len + 1;
				h = valueH2[goal->state[last->sp] ^ 0x20][goal->sp] - valueH2[goal->state[last->sp] ^ 0x20][last->sp];
				last->f = goal->f + h + 1;
				leaf[(h+1)>>1].push(last);
				last = NULL;
			}
		}
		innode.insert(string(goal->state + 1));
		do{
			free(goal->path);
			free(goal);
			if (leaf[0].empty()){
				tempList = leaf[0];
				leaf[0] = leaf[1];
				leaf[1] = tempList;
			}
			goal = leaf[0].top();
			leaf[0].pop();
		} while (innode.find(string(goal->state + 1)) != endit);
		len = goal->g;
	}
	return goal->path;
}
void destory(){
	free(goal->path);
	free(goal);
	goal = NULL;
	innode.clear();
}
void print(char * state){
	for (int i = 0; i < 27;){
		cout << " " << (int)(state[i++] ^ 0x20);
		if (i % 3 == 0)	cout << endl;
		if (i % 9 == 0) cout << endl;
	}
}
void state_initial_file(){
	ifstream source("source.txt"), target("target.txt");
	int t, i;
	for (i = 0; i < 27; i++){
		source >> t;
		state0[i] = (char)(t ^ 0x20);
		if (t == -1){
			if ((oper[i] >> 5) & 0x01){
				oper[i - 3] ^= 0x10;
			}
			if ((oper[i] >> 4) & 0x01){
				oper[i + 3] ^= 0x20;
			}
			if ((oper[i] >> 3) & 0x01){
				oper[i - 1] ^= 0x04;
			}
			if ((oper[i] >> 2) & 0x01){
				oper[i + 1] ^= 0x08;
			}
			if ((oper[i] >> 1) & 0x01){
				oper[i - 9] ^= 0x01;
			}
			if ((oper[i] >> 0) & 0x01){
				oper[i + 9] ^= 0x02;
			}
		}
		target >> t;
		stateN[i] = (char)t;
	}
	source.close();
	target.close();
	unsigned char apos, bpos, cpos;
	memset(valueH2, 0, 27 * 27);
	for (i = 0; i < 27; i++){
		if (stateN[i] > 0){
			apos = i / 9;
			bpos = i % 3;
			cpos = i / 3 % 3;
			for (int a = 0; a < 3; a++){
				for (int b = 0; b < 3; b++){
					for (int c = 0; c < 3; c++){
						valueH2[stateN[i]][a * 9 + b + c * 3] = abs(apos - a) + abs(bpos - b) + abs(cpos - c);
					}
				}
			}
		}
		stateN[i] ^= 0x20;
	}
}
int main(int argc, char** argv){
	state_initial_file();
	clock_t start, finish;
	double totaltime;
	start = clock();
	char *path = ASH2();
	finish = clock();
	ofstream output("output_Ah2.txt");
	totaltime = (double)(finish - start) / CLOCKS_PER_SEC;
	output << totaltime*1000 << endl;
	if (path == NULL){
		output << "Can't find path" << endl;
	}
	else {
		output << path << endl;
	}
	output.close();
	destory();
	return 0;
}
